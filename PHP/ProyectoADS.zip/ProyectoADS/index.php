<?php
$included = include_once("./moduloseguridad/formAutenticarUsuario.php");

$objFormAutenticar = new formAutenticarUsuario();
$objFormAutenticar->formAutenticarUsuarioShow();

?>
